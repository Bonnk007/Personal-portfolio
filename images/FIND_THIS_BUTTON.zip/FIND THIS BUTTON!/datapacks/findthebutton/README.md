# Datapack Template Made By Bret06
## Datapack Template for Minecraft: Java Edition

www.bret06.net

This is a free to use datapack template for anyone looking to start making datapacks!
